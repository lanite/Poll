'use client'
import Link from 'next/link'
import { motion } from 'framer-motion'

const FEATURES = [
  { emoji: '⚡', title: 'Live Results', desc: 'Votes update in real-time as they come in' },
  { emoji: '🔥', title: 'Viral Templates', desc: 'Hot Take, This vs That, Emoji Reactions & more' },
  { emoji: '🎨', title: 'Beautiful Themes', desc: 'Every poll looks stunning on any device' },
  { emoji: '🚀', title: 'Instant Sharing', desc: 'Custom social cards auto-generated for every poll' },
  { emoji: '🎉', title: 'Confetti Moments', desc: 'Voting feels like an event, not a chore' },
  { emoji: '📊', title: 'Analytics', desc: 'See how your poll spreads in real-time' },
]

const EXAMPLES = [
  { emoji: '⚔️', q: 'Tabs vs Spaces — settle this once and for all', votes: '24.7k' },
  { emoji: '🔥', q: 'Is a hot dog a sandwich?', votes: '89.2k' },
  { emoji: '🍕', q: "What's the best pizza topping?", votes: '43.1k' },
]

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-950 overflow-hidden">
      {/* Nav */}
      <nav className="flex items-center justify-between px-6 py-4 max-w-6xl mx-auto">
        <div className="font-black text-2xl gradient-text">ViralPoll</div>
        <Link
          href="/create"
          className="bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold px-5 py-2 rounded-full text-sm hover:opacity-90 transition-opacity"
        >
          Create poll
        </Link>
      </nav>

      {/* Hero */}
      <section className="max-w-4xl mx-auto px-6 pt-20 pb-24 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="inline-flex items-center gap-2 bg-purple-500/10 border border-purple-500/30 text-purple-300 text-sm font-medium px-4 py-2 rounded-full mb-8">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-purple-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-purple-500" />
            </span>
            Live polls happening right now
          </div>

          <h1 className="text-5xl md:text-7xl font-black leading-tight mb-6">
            Polls that people{' '}
            <span className="gradient-text">actually share</span>
          </h1>
          <p className="text-xl text-gray-400 mb-10 max-w-2xl mx-auto leading-relaxed">
            Create beautiful, viral-ready polls in seconds. Watch votes roll in live.
            Every poll auto-generates a stunning social card.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href="/create"
              className="w-full sm:w-auto bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold px-10 py-4 rounded-2xl text-lg hover:opacity-90 transition-opacity"
            >
              🚀 Create a free poll
            </Link>
            <Link
              href="/poll/hot-dog-sandwich-demo123"
              className="w-full sm:w-auto bg-white/5 border border-white/10 text-white font-semibold px-10 py-4 rounded-2xl text-lg hover:bg-white/10 transition-colors"
            >
              See an example →
            </Link>
          </div>
        </motion.div>
      </section>

      {/* Example polls */}
      <section className="max-w-4xl mx-auto px-6 pb-24">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {EXAMPLES.map((ex, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + i * 0.1 }}
              className="bg-gray-900 rounded-2xl p-5 border border-white/5 hover:border-purple-500/30 transition-colors cursor-pointer"
            >
              <div className="text-3xl mb-3">{ex.emoji}</div>
              <div className="font-semibold mb-3 leading-snug">{ex.q}</div>
              <div className="text-sm text-gray-500">{ex.votes} votes</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Features grid */}
      <section className="max-w-5xl mx-auto px-6 pb-24">
        <h2 className="text-3xl font-black text-center mb-12">
          Built to go viral
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {FEATURES.map((f, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="bg-gray-900 rounded-2xl p-6 border border-white/5"
            >
              <div className="text-3xl mb-3">{f.emoji}</div>
              <div className="font-bold text-lg mb-1">{f.title}</div>
              <div className="text-gray-400 text-sm">{f.desc}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-3xl mx-auto px-6 pb-24 text-center">
        <div className="bg-gradient-to-br from-purple-900/40 to-pink-900/40 border border-purple-500/20 rounded-3xl p-12">
          <h2 className="text-4xl font-black mb-4">Ready to go viral?</h2>
          <p className="text-gray-400 mb-8">Free forever. No account needed to vote.</p>
          <Link
            href="/create"
            className="inline-block bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold px-12 py-4 rounded-2xl text-lg hover:opacity-90 transition-opacity"
          >
            Create your poll now
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/5 text-center py-8 text-gray-600 text-sm">
        Built with Next.js, Supabase & ❤️
      </footer>
    </div>
  )
}
