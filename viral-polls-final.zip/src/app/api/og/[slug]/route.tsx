import { ImageResponse } from 'next/og'
import { createClient } from '@supabase/supabase-js'

export const runtime = 'edge'

interface PollOption { text: string }
interface RawResult { option_index: number; vote_count: number }

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params
    const supabase = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY!
    )

    const [{ data: poll }, { data: results }] = await Promise.all([
      supabase.from('polls').select('title, options').eq('slug', slug).single(),
      supabase.rpc('get_poll_results', { poll_slug: slug }),
    ])

    const options: PollOption[] = poll?.options || []
    const rawResults: RawResult[] = results || []
    const total = rawResults.reduce((s, r) => s + Number(r.vote_count), 0)
    const sorted = [...rawResults].sort((a, b) => Number(b.vote_count) - Number(a.vote_count))
    const top = sorted[0]
    const winningText = top ? (options[top.option_index]?.text ?? '') : ''
    const winningPct = total > 0 ? Math.round((Number(top?.vote_count ?? 0) / total) * 100) : 0
    const title: string = poll?.title ?? 'Vote now'

    return new ImageResponse(
      (
        <div style={{ display:'flex', flexDirection:'column', width:'1200px', height:'630px', background:'linear-gradient(135deg,#0f0c29,#302b63,#24243e)', padding:'56px 64px', fontFamily:'system-ui,sans-serif', color:'white', position:'relative', overflow:'hidden' }}>
          <div style={{ position:'absolute', top:'-120px', right:'-120px', width:'500px', height:'500px', background:'radial-gradient(circle,rgba(139,92,246,0.25) 0%,transparent 70%)', borderRadius:'50%' }} />
          <div style={{ display:'flex', alignItems:'center', background:'rgba(139,92,246,0.15)', border:'1px solid rgba(139,92,246,0.4)', borderRadius:'100px', padding:'8px 22px', fontSize:'16px', color:'#c4b5fd', fontWeight:700, marginBottom:'36px', width:'fit-content', letterSpacing:'0.06em' }}>
            {'🗳 LIVE POLL · ' + total.toLocaleString() + ' VOTES'}
          </div>
          <div style={{ fontSize: title.length > 60 ? '42px' : '54px', fontWeight:900, lineHeight:1.15, marginBottom:'40px', maxWidth:'1000px', letterSpacing:'-0.02em' }}>
            {title}
          </div>
          {winningText && total > 0 ? (
            <div style={{ display:'flex', alignItems:'center', gap:'16px', background:'rgba(255,255,255,0.06)', border:'1px solid rgba(255,255,255,0.1)', borderRadius:'20px', padding:'18px 28px', maxWidth:'900px' }}>
              <span style={{ fontSize:'30px' }}>👑</span>
              <span style={{ fontSize:'24px', fontWeight:700, flex:1 }}>{winningText}</span>
              <div style={{ background:'linear-gradient(90deg,#8B5CF6,#EC4899)', borderRadius:'12px', padding:'6px 18px', fontSize:'32px', fontWeight:900 }}>
                {winningPct + '%'}
              </div>
            </div>
          ) : (
            <div style={{ display:'flex', flexDirection:'column', gap:'10px' }}>
              {options.slice(0, 3).map((opt, i) => (
                <div key={i} style={{ display:'flex', background:'rgba(255,255,255,0.05)', border:'1px solid rgba(255,255,255,0.08)', borderRadius:'14px', padding:'14px 22px', fontSize:'22px', fontWeight:600 }}>
                  {opt.text}
                </div>
              ))}
            </div>
          )}
          <div style={{ position:'absolute', bottom:'50px', left:'64px', fontSize:'20px', fontWeight:900, color:'#a78bfa' }}>ViralPoll</div>
          <div style={{ position:'absolute', bottom:'52px', right:'64px', fontSize:'18px', color:'rgba(255,255,255,0.35)' }}>Cast your vote →</div>
        </div>
      ),
      { width: 1200, height: 630 }
    )
  } catch (err) {
    console.error('OG error:', err)
    return new ImageResponse(
      (<div style={{ display:'flex', alignItems:'center', justifyContent:'center', width:'1200px', height:'630px', background:'#0f0c29', color:'white', fontSize:'52px', fontWeight:900, fontFamily:'system-ui' }}>{'🗳️ ViralPoll'}</div>),
      { width: 1200, height: 630 }
    )
  }
}
