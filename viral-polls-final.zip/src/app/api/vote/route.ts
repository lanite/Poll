import { createClient } from '@supabase/supabase-js'
import { NextRequest, NextResponse } from 'next/server'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { poll_id, option_index, voter_fingerprint } = body

    if (!poll_id || option_index === undefined || option_index === null || !voter_fingerprint) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    // Validate option_index is a number
    if (typeof option_index !== 'number' || option_index < 0) {
      return NextResponse.json({ error: 'Invalid option' }, { status: 400 })
    }

    // Get the poll to validate option index
    const { data: poll, error: pollError } = await supabase
      .from('polls')
      .select('id, options, is_active, ends_at')
      .eq('id', poll_id)
      .single()

    if (pollError || !poll) {
      return NextResponse.json({ error: 'Poll not found' }, { status: 404 })
    }

    if (!poll.is_active) {
      return NextResponse.json({ error: 'Poll is closed' }, { status: 403 })
    }

    if (poll.ends_at && new Date(poll.ends_at) < new Date()) {
      return NextResponse.json({ error: 'Poll has ended' }, { status: 403 })
    }

    const options = poll.options as { id: string; text: string }[]
    if (option_index >= options.length) {
      return NextResponse.json({ error: 'Invalid option index' }, { status: 400 })
    }

    // Record IP hash for basic abuse prevention
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0] || 
                req.headers.get('x-real-ip') || 
                'unknown'
    const ipHash = Buffer.from(ip).toString('base64').slice(0, 16)

    const { error } = await supabase.from('votes').insert({
      poll_id,
      option_index,
      voter_fingerprint,
      metadata: { ip_hash: ipHash },
    })

    if (error) {
      // Unique constraint = already voted
      if (error.code === '23505') {
        return NextResponse.json({ error: 'Already voted', code: 'ALREADY_VOTED' }, { status: 409 })
      }
      console.error('Vote insert error:', error)
      return NextResponse.json({ error: 'Failed to record vote' }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (err) {
    console.error('Vote route error:', err)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
