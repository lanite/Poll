import { createClient } from '@supabase/supabase-js'
import { NextRequest, NextResponse } from 'next/server'

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!
)

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const { data, error } = await supabase
    .from('polls')
    .select('*')
    .eq('id', id)
    .single()

  if (error) return NextResponse.json({ error: 'Poll not found' }, { status: 404 })
  return NextResponse.json({ poll: data })
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await req.json()

    if (body.increment_share) {
      await supabase.rpc('increment_share_count', { poll_id: id }).catch(() => null)
      return NextResponse.json({ success: true })
    }

    return NextResponse.json({ error: 'Unknown operation' }, { status: 400 })
  } catch {
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
