'use client'
import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import Link from 'next/link'

// Simple nanoid alternative
function uid(len = 8) {
  return Math.random().toString(36).slice(2, 2 + len)
}

const TEMPLATES = [
  {
    id: 'versus',
    name: '⚔️ This vs That',
    description: 'Classic two-choice battle',
    defaultOptions: ['Option A', 'Option B'],
    maxOptions: 2,
    gradient: 'from-red-500 to-orange-500',
  },
  {
    id: 'hot-take',
    name: '🔥 Hot Take',
    description: 'Agree or disagree?',
    defaultOptions: ['Agree 🔥', 'Disagree ❄️'],
    maxOptions: 2,
    gradient: 'from-orange-500 to-yellow-500',
  },
  {
    id: 'ranked',
    name: '🏆 Ranked Choice',
    description: 'Pick your favorites (up to 6)',
    defaultOptions: ['Option 1', 'Option 2', 'Option 3'],
    maxOptions: 6,
    gradient: 'from-purple-500 to-pink-500',
  },
  {
    id: 'emoji-only',
    name: '😍 Emoji Reaction',
    description: 'Pure emoji voting',
    defaultOptions: ['😍', '🤔', '😂', '💯'],
    maxOptions: 8,
    gradient: 'from-yellow-400 to-pink-500',
  },
  {
    id: 'standard',
    name: '📊 Standard Poll',
    description: 'Classic multi-choice poll',
    defaultOptions: ['Option 1', 'Option 2'],
    maxOptions: 8,
    gradient: 'from-blue-500 to-cyan-500',
  },
]

const THEMES = [
  { id: 'gradient-purple', label: 'Purple', class: 'from-purple-600 to-pink-600' },
  { id: 'gradient-ocean', label: 'Ocean', class: 'from-blue-600 to-cyan-500' },
  { id: 'gradient-fire', label: 'Fire', class: 'from-orange-500 to-red-600' },
  { id: 'gradient-forest', label: 'Forest', class: 'from-green-500 to-emerald-600' },
  { id: 'dark', label: 'Dark', class: 'from-gray-700 to-gray-900' },
]

type Step = 'template' | 'build' | 'settings'

export default function CreatePoll() {
  const router = useRouter()
  const supabase = createClient()
  const [step, setStep] = useState<Step>('template')
  const [template, setTemplate] = useState(TEMPLATES[0])
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [options, setOptions] = useState<string[]>(['', ''])
  const [theme, setTheme] = useState(THEMES[0].id)
  const [loading, setLoading] = useState(false)
  const [showResultsBeforeVote, setShowResultsBeforeVote] = useState(false)
  const [error, setError] = useState('')

  const addOption = () => {
    if (options.length < template.maxOptions) setOptions([...options, ''])
  }

  const updateOption = (index: number, value: string) => {
    const updated = [...options]
    updated[index] = value
    setOptions(updated)
  }

  const removeOption = (index: number) => {
    if (options.length > 2) setOptions(options.filter((_, i) => i !== index))
  }

  const handleTemplateSelect = (t: (typeof TEMPLATES)[0]) => {
    setTemplate(t)
    setOptions([...t.defaultOptions])
    setStep('build')
  }

  const generateSlug = (text: string) => {
    const base = text
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, '')
      .replace(/\s+/g, '-')
      .slice(0, 40)
    return `${base}-${uid(6)}`
  }

  const handleSubmit = async () => {
    if (!title.trim() || options.filter((o) => o.trim()).length < 2) return
    setLoading(true)
    setError('')

    const slug = generateSlug(title)
    const OPTION_COLORS = ['#8B5CF6', '#EC4899', '#F59E0B', '#10B981', '#3B82F6', '#EF4444', '#14B8A6', '#F97316']
    const pollOptions = options
      .filter((o) => o.trim())
      .map((text, i) => ({
        id: uid(8),
        text: text.trim(),
        color: OPTION_COLORS[i % OPTION_COLORS.length],
      }))

    const { data, error: dbError } = await supabase
      .from('polls')
      .insert({
        slug,
        title: title.trim(),
        description: description.trim() || null,
        options: pollOptions,
        template: template.id,
        theme,
        settings: { show_results_before_vote: showResultsBeforeVote },
      })
      .select()
      .single()

    setLoading(false)
    if (data && !dbError) {
      router.push(`/poll/${slug}`)
    } else {
      setError(dbError?.message || 'Something went wrong. Please try again.')
    }
  }

  const canProceed = title.trim().length > 0 && options.filter((o) => o.trim()).length >= 2

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      {/* Progress bar */}
      <div className="h-1 bg-gray-800">
        <motion.div
          className="h-full bg-gradient-to-r from-purple-500 to-pink-500"
          animate={{
            width: step === 'template' ? '33%' : step === 'build' ? '66%' : '100%',
          }}
          transition={{ duration: 0.4 }}
        />
      </div>

      {/* Back to home */}
      <div className="max-w-2xl mx-auto px-4 pt-4">
        <Link href="/" className="text-gray-500 hover:text-gray-300 text-sm transition-colors">
          ← ViralPoll
        </Link>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-10">
        <AnimatePresence mode="wait">

          {/* Step 1: Template */}
          {step === 'template' && (
            <motion.div
              key="template"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <h1 className="text-4xl font-black mb-2">Create a poll</h1>
              <p className="text-gray-400 mb-8">Pick a template to get started fast</p>
              <div className="grid grid-cols-1 gap-3">
                {TEMPLATES.map((t) => (
                  <motion.button
                    key={t.id}
                    onClick={() => handleTemplateSelect(t)}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="flex items-center gap-4 p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-white/30 text-left transition-all group"
                  >
                    <div
                      className={`w-12 h-12 rounded-xl bg-gradient-to-br ${t.gradient} flex items-center justify-center text-2xl flex-shrink-0`}
                    >
                      {t.name.split(' ')[0]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-lg">{t.name.split(' ').slice(1).join(' ')}</div>
                      <div className="text-white/50 text-sm">{t.description}</div>
                    </div>
                    <div className="text-white/30 group-hover:text-white/60 transition-colors">→</div>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}

          {/* Step 2: Build */}
          {step === 'build' && (
            <motion.div
              key="build"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              <button
                onClick={() => setStep('template')}
                className="text-gray-400 hover:text-white flex items-center gap-2 text-sm transition-colors"
              >
                ← Back
              </button>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Poll question <span className="text-red-400">*</span>
                </label>
                <textarea
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="What's the best pizza topping?"
                  className="w-full bg-gray-900 border border-gray-700 rounded-xl px-4 py-3 text-xl font-bold placeholder-gray-600 focus:outline-none focus:border-purple-500 resize-none transition-colors"
                  rows={2}
                  maxLength={200}
                  autoFocus
                />
                <div className="text-right text-xs text-gray-600 mt-1">{title.length}/200</div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-2">
                  Description <span className="text-gray-600">(optional)</span>
                </label>
                <input
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Add context or a subtitle..."
                  className="w-full bg-gray-900 border border-gray-700 rounded-xl px-4 py-3 placeholder-gray-600 focus:outline-none focus:border-purple-500 transition-colors"
                  maxLength={300}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-400 mb-3">
                  Options <span className="text-gray-600">({options.filter(o => o.trim()).length}/{template.maxOptions} max)</span>
                </label>
                <div className="space-y-2">
                  <AnimatePresence>
                    {options.map((opt, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 10 }}
                        className="flex gap-2 items-center"
                      >
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-sm font-bold flex-shrink-0">
                          {i + 1}
                        </div>
                        <input
                          value={opt}
                          onChange={(e) => updateOption(i, e.target.value)}
                          placeholder={`Option ${i + 1}`}
                          className="flex-1 bg-gray-900 border border-gray-700 rounded-xl px-4 py-3 focus:outline-none focus:border-purple-500 transition-colors"
                          maxLength={100}
                        />
                        {options.length > 2 && (
                          <button
                            onClick={() => removeOption(i)}
                            className="text-gray-600 hover:text-red-400 w-8 h-8 flex items-center justify-center transition-colors"
                          >
                            ✕
                          </button>
                        )}
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
                {options.length < template.maxOptions && (
                  <button
                    onClick={addOption}
                    className="mt-3 text-purple-400 hover:text-purple-300 text-sm flex items-center gap-2 transition-colors"
                  >
                    + Add option
                  </button>
                )}
              </div>

              {/* Theme picker */}
              <div>
                <label className="block text-sm font-medium text-gray-400 mb-3">Theme color</label>
                <div className="flex gap-3">
                  {THEMES.map((t) => (
                    <button
                      key={t.id}
                      onClick={() => setTheme(t.id)}
                      title={t.label}
                      className={`w-10 h-10 rounded-full bg-gradient-to-br ${t.class} border-2 transition-all ${
                        theme === t.id ? 'border-white scale-110 shadow-lg' : 'border-transparent opacity-60 hover:opacity-100'
                      }`}
                    />
                  ))}
                </div>
              </div>

              <motion.button
                onClick={() => setStep('settings')}
                disabled={!canProceed}
                whileTap={{ scale: 0.97 }}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold py-4 rounded-2xl text-lg disabled:opacity-40 disabled:cursor-not-allowed transition-opacity"
              >
                Continue →
              </motion.button>
            </motion.div>
          )}

          {/* Step 3: Settings & Launch */}
          {step === 'settings' && (
            <motion.div
              key="settings"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              <button
                onClick={() => setStep('build')}
                className="text-gray-400 hover:text-white flex items-center gap-2 text-sm transition-colors"
              >
                ← Back
              </button>

              <div>
                <h2 className="text-2xl font-black mb-1">Almost ready!</h2>
                <p className="text-gray-400 text-sm">Review your poll and choose settings</p>
              </div>

              {/* Preview */}
              <div className="bg-gray-900 rounded-2xl p-5 border border-white/5">
                <div className="text-xs text-gray-500 mb-2 uppercase tracking-wider">Preview</div>
                <div className="font-bold text-lg mb-3">{title}</div>
                <div className="space-y-2">
                  {options.filter((o) => o.trim()).map((opt, i) => (
                    <div key={i} className="bg-white/5 rounded-lg px-3 py-2 text-sm">
                      {opt}
                    </div>
                  ))}
                </div>
              </div>

              {/* Settings toggles */}
              <div className="space-y-3">
                <label className="flex items-center justify-between p-4 bg-gray-900 rounded-2xl cursor-pointer border border-white/5 hover:border-white/10 transition-colors">
                  <div>
                    <div className="font-medium">Show results before voting</div>
                    <div className="text-sm text-gray-400">Voters see live results without needing to vote first</div>
                  </div>
                  <div
                    onClick={() => setShowResultsBeforeVote(!showResultsBeforeVote)}
                    className={`w-12 h-6 rounded-full transition-colors flex-shrink-0 ml-4 relative cursor-pointer ${
                      showResultsBeforeVote ? 'bg-purple-500' : 'bg-gray-700'
                    }`}
                  >
                    <div
                      className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform shadow ${
                        showResultsBeforeVote ? 'translate-x-7' : 'translate-x-1'
                      }`}
                    />
                  </div>
                </label>
              </div>

              {error && (
                <div className="bg-red-900/30 border border-red-500/30 text-red-300 px-4 py-3 rounded-xl text-sm">
                  {error}
                </div>
              )}

              <motion.button
                onClick={handleSubmit}
                disabled={loading}
                whileTap={{ scale: 0.97 }}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold py-4 rounded-2xl text-lg flex items-center justify-center gap-2 disabled:opacity-70"
              >
                {loading ? (
                  <>
                    <span className="animate-spin inline-block">⟳</span>
                    Launching...
                  </>
                ) : (
                  '🚀 Launch Poll'
                )}
              </motion.button>
            </motion.div>
          )}

        </AnimatePresence>
      </div>
    </div>
  )
}
